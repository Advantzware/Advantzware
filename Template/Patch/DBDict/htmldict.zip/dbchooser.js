function writeDbChooser()
{
}